#pragma once
#include "statementnode.h"
#include "astnode.h"
#include "expressionnode.h"


class printnode: public statementnode
{
	public:
		printnode(expressionnode * expr): statementnode()
		{ AddChild(expr);}
};
