#pragma once
#include "astnode.h"
#include "blocknode.h"

class programnode: public astnode
{
    public:
    	programnode(blocknode * block) : astnode() {AddChild(block);}
};
