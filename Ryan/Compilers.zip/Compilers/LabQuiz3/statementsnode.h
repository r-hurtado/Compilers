#pragma once
#include "statementnode.h"

class statementsnode : public astnode
{
   public:
   	statementsnode(): astnode(){}
   	statementsnode(statementnode *  stmt) : astnode)
   	{
   	  AddChild(stmt);
   	}
	void Insert(statementnode *  stmt)
	{ AddChild(stmt);}
	
};
