#pragma once
#include "astnode.h"
#include "statementsnode.h"
#include "statementnode.h"
#include "blocknode.h"
#include "programnode.h"
#include "expressionnode.h"
#include "preexprnode.h"
#include "printnode.h"
#include "assignnode.h"

