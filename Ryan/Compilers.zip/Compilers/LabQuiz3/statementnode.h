#pragma once
#include "astnode.h"

class statementnode: public astnode
{
    public:
        statementnode(): astnode() {}
};
