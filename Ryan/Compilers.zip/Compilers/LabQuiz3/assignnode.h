#pragma once
#include "statementnode.h"
#include "cSymbol.h"

class assignnode: public statementnode
{
    public:
    	assignnode(cSymbol * ident, expressionnode* exp): statementnode()
    	{
    	    AddChild(ident);
    	    AddChild(exp);
    	}
};

