#pragma once
#include "astnode.h"
#include "statementnode.h"

class expressionnode: public statementnode()
{
	public:
		expressionnode(): statementnode() {}
};
