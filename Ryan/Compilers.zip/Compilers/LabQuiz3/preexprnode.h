#pragma once
#include "expressionnode.h"
#include "opnode.h"


class preexprnode: public expressionnode
{
	public:
		preexprnode(int op, expressionnode* expr1,  expressionnode* expr2): expressionnode()
		{
			AddChild(new opnode(op));
			AddChild(expr1);
			AddChild(expr2);
		}
};
