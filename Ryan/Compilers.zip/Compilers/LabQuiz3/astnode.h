#pragma once
#include <string>
#include <vector>
using std::string;
using std::vector;


class astnode
{
   public:
       astnode(){}
       
       void AddChild(astnode * child){m_children.push_back(child);}
   protected:
       vector<astnode *> m_children;
       
};
