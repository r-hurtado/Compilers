#pragma once
#include "astnode.h"
#include "statementnode.h"
#include "statementsnode.h"

class blocknode : public statementnode
{
	public:
	    blocknode(statementsnode * stmts): statementnode() {AddChild(stmts);}
};
