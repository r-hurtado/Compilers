#pragma once
#include "astnode.h"

class opnode: public astnode
{
	public:
		opnode(int op): astnode()
		{ m_op = op;}
	protected:
		int m_op;

};
