#pragma once

void Error(std::string expecting);
int PeekToken();
int AdvanceToken();
