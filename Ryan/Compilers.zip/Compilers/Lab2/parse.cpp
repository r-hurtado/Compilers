//**************************************
// parse.cps
//
// Starting point for top-down recursive-descent parser
// Used in CST 320 Labs
//
// Author: Ryan Williams 
// ryan.williams@oit.edu
//
// Date:Jan. 12, 2015
//

#include <iostream>
#include "lex.h"
#include "parse.h"
#include "tokens.h"
#include "utils.h"

//*******************************************

/*******************************************
bool FindExample()
{
    if (!FindPART1()) return false;
    
    int token = PeekToken();
    if (token != '+') return false;
    AdvanceToken();         // past '+'

    if (!FindPART2()) return false;

    return true;
}
*/

bool FindPROG()
{
    while (PeekToken() != 0)
    {
        FindSTMTS();
	
	if (PeekToken() == END )
	{
	    AdvanceToken();
	    return true;  
	}
	AdvanceToken();
    }
    return false; 
}

bool FindSTMTS()
{
    if(FindSTMT())
    {
	if(!FindSTMTS())
        {
	    return false;
        } 
	return true;
    } // found a lamda

    return true; //because lamda
}

bool FindSTMT()
{
    if(!FindEXPR())
    {
	return false;
    }
    if(PeekToken() != ';')
    {
	Error("';'");
	return false;
    }
    AdvanceToken(); 
    std::cout << "Found a statement\n";
    return true;
}

bool FindEXPR()
{
    if (FindTERM())
    {
	return true;
    }

    if (PeekToken()!= '(' )
    {
        //Error("(");		//error when it finds an end
        return false;
    }
    AdvanceToken();
    if (!FindEXPR())
    {
        return false;
    }
    if (PeekToken() != ')' )
    {
        Error("')'");
        return false;
    }
    AdvanceToken();
    if (!FindEXPR_P())
    {
        return false;
    }

    return true;	
}

bool FindEXPR_P()
{
    if(FindPLUSOP())
    {
	if (PeekToken() != '(')
	{
	    Error("'('");          //error when it finds an end
	    return false;
	}
	AdvanceToken();
	if(!FindEXPR())
	{
	    return false;
	}
	if (PeekToken() != ')')
	{
	    Error("')'");
	    return false;
	}
	AdvanceToken();
	if(!FindEXPR_P())
	{
	    return false;
	}
	return true;
    }
    return true;
}

bool FindPLUSOP()
{
    if (PeekToken() != '+' && PeekToken() != '-')
    {
	return false;
    }
    AdvanceToken();
    return true;	
}

bool FindTERM()
{
    if (PeekToken() != INT_VAL)
    {
	if (PeekToken() != '[')
        {
	   //Error("[");     //there is a error here finding  "(" three times, and "end" once
	   return false;
	}
	AdvanceToken();
	if (!FindEXPR()) 
	{
	    return false;
	}
	if (PeekToken() != ']')
	{
	    Error("']'"); // missing a error 
	    return false;
	}
	AdvanceToken();
	if (!FindTERM_P())
	{
	     return false;
	}
	
	return true;
    }
    AdvanceToken(); 
    return true;
}

bool FindTERM_P()
{
    if (!FindTIMESOP())
    {
	return true;
    }
    if (PeekToken() != '[')
    {
	Error("'['");         
	return false;
    }
    AdvanceToken();
    if(!FindEXPR())
    {
	return false;
    }
    if (PeekToken() != ']')
    {
	Error("']'");  
	return false;
    }
    AdvanceToken();
    if(!FindTERM_P())
    {
	return false;
    }
    return true;
}

bool FindTIMESOP()
{
    if (PeekToken() != '*' && PeekToken() != '/')
    {
        return false;
    }
    AdvanceToken();
    return true; 
}
